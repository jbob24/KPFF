--select *
--from tblweeks

insert into tblWeeks (WeekNo, WeekNoYear, WeekNoMonth, WeekNoDay, WeekNoStartDate)
values (53, 2012, 12, 31, '2012-12-31 00:00:00.000')